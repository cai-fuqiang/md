#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <sys/stat.h>

#include "list.h"

#define NUM_THREADS 3

LIST_HEAD(obj_list_head);

#define PKGSIZE  65536

#define CHAR_START	('a')
#define CHAR_END	('a')

#define OBJ_NUM		1024

#define pr_err_exit(fmt, ...)
	do {
		printf("[ERR] "fmt" EXIT !\n", __VA_ARGS__);
		exit(1);
	} while(0)

#define pr_debug(fmt, ...)
	do {
#ifdef DEBUG
		printf("[DEG] "fmt" \n", __VA_ARGS__);
#endif
	} while(0)

#define pr_warn(fmt, ...)
	do {
		printf("[WARN] "fmt" \n", __VA_ARGS__);
	} while(0)

struct obj {
	int idx;
	struct list_head list;
	char data;
	char *page;
	pthread_mutex_t lock;
};

enum obj_op {
	ALLOC = 0,
	FREE
};

void *consumer(void *arg) {
	return NULL;
}

void *alloc_mem(size_t size) 
{
	void *ptr;
	ptr = (void *)mmap(NULL, size, PROT_READ|PROT_WRITE,MAP_SHARED|MAP_ANONYMOUS,-1,0);

	if (ptr) {
		pr_err_exit("mmap mem error");
	}

	return ptr;
}

void free_mem(void *ptr, size_t size)
{
	int ret;
	ret = munmap(ptr, size);

	if (ret) {
		pr_err_exit("munmap error\n");
	}
	return;
}


void free_obj(struct obj *obj)
{
	free_mem(obj->page);
	obj->page = NULL;
	obj->
}
void check_access_old_tlb(struct obj *obj, enum obj_op)
{
	char obj_data;
	char page_data;
	int need_warn_print = 0;

	obj_data = obj->data
	if (obj_data) {
		if (obj->page) {
			page_data = obj->page[0];
			if (obj->data != obj->page[0]) {
				need_warn_print = 1;
			}
		} else {
			page_data = '\0';
			need_warn_print = 1;
		}
		if (obj_op == FREE) {
			free_obj(obj);
		}
	} else {
		if (obj->page) {
			page_data = obj->page[0];
			goto warn_print;
		}
	}
	if (need_warn_print) 
		pr_warn("access obj(%c) obj.data(%c) obj", obj_data, page_data);
	return;
}
void *producer(void *arg) {
	struct obj *p, *n;
	while (1) {
		list_for_each_entry_safe(p, n, &obj_list_head, list) {
			pthread_mutex_lock(&p->lock);
			check_access_old_tlb();
			pthread_mutex_unlock(&p->lock);
		}
	}
	return NULL;
}

void init_one_obj(struct obj *obj, int idx)
{
	int err ;
	err = pthread_mutex_init(&obj->lock, NULL);
	if (err) {
		pr_err_exit("init lock error");
	}
	obj->data = '\0';
	obj->page = NULL;
	obj->idx = i;
	list_add(&obj->list, &obj_list_head);
	return;
}

void init_list()
{
	struct obj *obj;

	int i = 0;

	while (i++ < OBJ_NUM) {
		obj = (struct obj *)malloc(sizeof(struct obj));
		
		if (!cur) {
			printf("init list , alloc obj error\n");
			exit(0);
		}
		init_one_obj(obj, i);
	}

	return;
}

void create_pid_file()
{
	pid_t pid;
	pid = getpid();

	FILE *fp;

	fp = fopen("/var/run/cve_test.pid", "w");

	if (!fp) {
		printf("fopen error\n");
		exit(1);
	}
	fprintf(fp, "%d\n", pid);

	fclose(fp);
}

void daemon_my()
{
	pid_t pid;
	int i;
 
    	pid = fork();
    	if(pid < 0)
    	{
    	    printf("Error Fork\n");
    	    exit(1);
    	}
    	else if(pid > 0)
    	{
    	    exit(0);
    	}
 
    	setsid();
    	chdir("/tmp");
    	umask(0);
 
    	for(i = 0; i< getdtablesize(); i++)
    	{
    	    close(i);
    	}
	return ;
}



int main()
{
	daemon_my();
	printf("start test\n");
	create_pid_file();
	pthread_mutexattr_t attr;
#if 0
	int err = pthread_mutex_init(&mtx, &attr);
	//assert(err == 0);
	if (err != 0) {
		printf("mutex init error\n");
		exit(1);
	}
	pthread_mutexattr_destroy(&attr);
#else
	int err = pthread_mutex_init(&mtx, NULL);
	//assert(err == 0);
	if (err != 0) {
		printf("mutex init error\n");
		exit(1);
	}
#endif

	pthread_attr_t attr1;
	pthread_t thread1;
	pthread_attr_init(&attr1);
	pthread_create(&thread1, &attr1, producer, NULL);

	pthread_attr_t attr2;
	pthread_t thread2;
	pthread_attr_init(&attr2);
	pthread_create(&thread2, &attr2, consumer, NULL);


	pthread_attr_t attr3;
	pthread_t thread3;
	pthread_attr_init(&attr3);
	pthread_create(&thread3, &attr3, consumer, NULL);


	pthread_attr_t attr4;
	pthread_t thread4;
	pthread_attr_init(&attr4);
	pthread_create(&thread4, &attr4, consumer, NULL);

	void *ret;
	pthread_join(thread1, &ret);
	pthread_join(thread2, &ret);
	pthread_join(thread3, &ret);
	pthread_join(thread4, &ret);

	return 0;
}
